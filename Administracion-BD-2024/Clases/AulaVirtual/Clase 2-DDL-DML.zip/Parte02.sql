/*
	SQL:	Structure Query Language
    
    ANSI SQL:
    
		DDL: Data Definition Language (Lenguaje de Definición de Datos)
        (Estructura de datos)
        (Baja compatibilidad con ANSI	50%)
        create table
        alter table
        drop table
        
        DML: Data Manipulation Language (Lenguaje de Manipulación de Datos)
        (Operación de registros)
        (Alta compatibilidad con ANSI	99%)
        select
        insert 
        delete
        update
	
    Tipo de datos más comunes
    
    Tipo de datos texto
    
    Tipo			Longitud
    char(x)			x
    varchar(x)    	x + 1
    
    nombre char(20)
    |ANA                 |				20 bytes
    |CARLOS              |				20 bytes
    |MAXIMILIANO         |				20 bytes
								Total:	60 bytes
                                
	nombre varchar(20)
    |ANA                 |			3 + 1 = 4 bytes
    |CARLOS              |			6 + 1 = 7 bytes
    |MAXIMILIANO         |			11+ 1 =12 bytes
								Total:     23 bytes
                                
	Tipo de datos numericos
    Tipo			Longitud
    boolean			1 byte
    tinyint			1 byte		
	smallint        2 bytes
	medium			3 bytes
    int integer		4 bytes
    bigint			8 bytes
    
    float			4 bytes
    double 			8 bytes
    decimal(t,d)	t+2 bytes
    
    codigo tinyint,			(signed)
    
		|--------|--------|
	  -128       0       127
	
    
    codigo tinyint unsigned,
		
        |-----------------|
		0				 255
        
	
    10/3
    
				3.333333
    float		--------
    
				3.333333333333333
    double		-----------------
    
    
    100/3
				33.33333
    float		--------
    
				33.33333333333333
    double		-----------------
    
    
    precio(7,2)		total= 7 + 2 = 9 bytes
    
				99999,99
				-----,--
                
	precio(8,2)		total= 8 + 2 = 10 bytes
    
				999999,99
                ------,--
                
                
	precio(7,3)		total= 7 + 2 = 9 bytes
    
				----,---
                
	Tipo de datos Fecha y Hora
    
    Tipo		Longitud
    date		3 bytes				'2021/09/01'
    time		3 bytes		
    datetime	8 bytes
    
*/

-- ctrol - enter

select 'Hola Mundo!';
select 2+2;
select 2+2 total;		-- agregar un alias de columna
select 2+2 as total;	-- no es necesario agregar la palabra as

-- más sobre alias
select 2+2 valor_total;
select 2+2 'valor total';

select pi() valor_PI;
select round(pi()) valor_PI;
select round(pi(),2) valor_PI;

select curdate() fecha_actual;		-- no ANSI
select curtime() hora_actual;		-- no ANSI
select sysdate() fecha_hora_actual;	-- no ANSI

-- Base de datos comercio
drop database if exists comercio;
create database comercio;
use comercio;
show databases;
show tables;

create table articulos(
	codigo int auto_increment primary key,
    descripcion varchar(255) not null,
    precio double,
    stock int
);

create table facturas(
	letra char(1),
    numero int,
    fecha date,
    monto double,
    primary key(letra,numero)	-- clave primaria compuesta.
);

create table clientes(
	codigo int auto_increment,
    nombre varchar(20) not null,
    apellido varchar(20) not null,
    cuit char(13),
    direccion varchar(20),
    comentarios varchar(140),
    primary key(codigo)
);


show tables;
describe articulos;
describe facturas;
describe clientes;

select * from articulos;
select * from facturas;
select * from clientes;

insert into articulos (descripcion,precio,stock) values
	('Martillo',99,20),
	('Lampara Led 3W',120,10),
	('Destornillador',55,20),
	('Pinza',250,60),
	('Pala',230,25);

insert into clientes (nombre,apellido,cuit,direccion) values
	('Juan','Perez','11111','Lima 222'),
	('Alejandra','Sosa','22222','Medrano 162'),
	('Jose','Soto','33333','Maipu 340'),
	('Mario','Garcia','44444','Viel 234'),
	('Javier','Lozano','55555','Peru 384');

select * from clientes;

insert into facturas(letra,numero,fecha,monto) values
	('a',1001,'2019/03/18',2500),
	('a',1002,curdate(),3000*1.21),
	('a',1003,curdate(),5000),
	('a',1004,curdate(),6000),
	('a',1005,curdate(),4000);

select * from facturas;

-- comandos DML select
-- * comodin: todos los campos
select * from clientes;
select nombre,apellido from clientes;
select apellido,nombre,apellido,curdate() fecha from clientes;

-- columnas calculadas
select codigo,descripcion,precio, 
	round(precio*1.21,2) precio_con_iva, stock
	from articulos;

-- no ANSI
select *,round(precio*1.21,2) precio_con_iva from articulos;




    










