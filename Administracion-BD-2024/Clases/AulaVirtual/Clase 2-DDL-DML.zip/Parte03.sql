show databases;
use comercio;
show tables;
describe articulos;
describe clientes;
describe facturas;

-- comodin * todos los campos
select * from articulos;
select descripcion,precio precio_sin_iva from articulos;

-- columnas calculadas
select codigo,descripcion,precio, 
	round(precio*1.21,2) precio_con_iva,stock 
    from articulos;

-- filtrado con where
select * from clientes where nombre='Juan';
select * from clientes where codigo=3;

-- Operador != <>  (Distinto)
select * from clientes where codigo<>3;
select * from clientes where codigo!=3;
select * from articulos where codigo!=3;

-- Operadores relacionales < <= >= >
select * from clientes where codigo>2;
select * from clientes where codigo>=2;
select * from articulos where precio<100;


-- insert into clientes (codigo,nombre,apellido) values (3,'','');
-- Error de clave duplicada.


-- Valores null
insert into clientes (nombre,apellido,direccion) values
('Ana','Morettu',''), ('Javier','Lopez',null);
insert into clientes (nombre,apellido) values
('Jorge','Sanchez'),('Apu','Supermarket');

select * from clientes where direccion='';
select * from clientes where direccion is null;
select * from clientes where direccion is not null;

select * from clientes where direccion=null;
-- no funciona

-- Operadores Logicos AND OR
select * from clientes where nombre='Juan' or nombre='Laura';
select * from clientes where nombre='jose' or nombre='carlos';
select * from clientes where nombre='Jose' and nombre='Carlos';

-- listado de personas(clientes) que viven en Lomas y Lanus
-- select * from clientes 
-- 	where localidad='lomas' or localidad='Lanus';

insert into articulos (descripcion,precio,stock) values
('Pintura 1L azul',250,20),
('Pintura 2L azul',300,20),
('Pintura 3L azul',350,20),
('Pintura 4L azul',400,20),
('Pintura 5L azul',450,20);

-- Articulos con precio entre 300 y 400
select * from articulos where precio>=300 and precio<=400;

select * from articulos where precio>=300 or precio<=400;

select * from articulos where precio<300 or precio>400;

-- Operador Between not between
select * from articulos where precio between 300 and 400;
select * from articulos where precio not between 300 and 400;

select * from clientes 	
	where codigo=2 
    or codigo=4
    or codigo=5
    or codigo=7
    or codigo=9;
    
-- Operador in not in
select * from clientes where codigo in(2,4,5,7,9);
select * from clientes where codigo not in(2,4,5,7,9);


-- Busqueda de expresiones like not like
insert into clientes (nombre,apellido) values
('Maria','Perez'),('Mariana','Perez'),
('Mario','Perez'),('Marcela','Perez'),
('Marcelo','Perez'),('Mirta','Perez'),
('Marta','Perez'),('Melina','Perez'),
('Monica','Perez'),('Micaela','Perez'),
('Omar','Perez'),('Armando','Perez');

select * from clientes where nombre like 'm%';
select * from clientes where nombre like 'ma%';
select * from clientes where nombre like 'mar%';
select * from clientes where nombre not like 'm%';
select * from clientes where nombre like '%a';
select * from clientes where nombre like 'm%a';
select * from clientes where nombre like '%ar%';
select * from clientes where nombre like 'm_r%';
select * from clientes where nombre like '___';
select * from clientes where nombre like '____';
select * from clientes where nombre like '_____%';

-- Ordenamiento con Order by
select * from clientes;
select * from clientes order by nombre;
select * from clientes order by nombre asc;
select * from clientes order by nombre desc;

insert into clientes (nombre,apellido) values
('silvia','Lopez'),('Silvia','Lopez'),('silvia','Lopez');

select * from clientes order by apellido,nombre;
select * from clientes order by apellido desc,nombre;

-- 1- Borrar si existe la base de datos Agenda.
drop database if exists agenda;
-- 2- Crear la base de datos Agenda.
create database agenda;
-- 3- Ingresar a la base de datos creada.
use agenda;
-- 4- Crear una tabla llamada "agenda". Debe tener los siguientes campos:

--    nombre (cadena de 20), 
--    domicilio (cadena de 30)
--    telefono (cadena de 11)
create table agenda(
	nombre varchar(20),
    domicilio varchar(20),
    telefono varchar(11)
);

-- 5- Visualizar las tablas existentes en la base de datos para verificar 
--    la creación de "agenda".
show tables;


-- 6- Visualizar la estructura de campos de la tabla "agenda". (describe).
describe agenda;

-- 7- Ingresar 10 registros con valores aleatorios.
insert into agenda (nombre,domicilio,telefono) values
('Mariela Fernandez','Medrano 162','12345678'),
('Raul','Peña 3455','87654321');

-- 8- Seleccione y muestre todos los registros de la tabla:
select * from agenda;


-- Ejercitacion
-- 1- Borrar si existe la base de datos comercio.

-- 2- Crear la base de datos comercio.

-- 3- Ingresar a la base de datos creada.

-- 4- Crear la tabla Clientes dentro de la base de datos con el siguiente detalle:

-- codigo		int auto_increment y PK
-- nombre		varchar(20) not null
-- apellido		varchar(20) not null
-- cuit			char(13)
-- direccion	varchar(50)
-- comentarios 	varchar(140)

-- PK significa Primary Key

-- 5- Crear la tabla Facturas dentro de la base de datos con el siguiente detalle:

-- Letra		char y PK
-- Numero		integer y PK
-- Fecha		date
-- Monto		double

-- observar que se esta declarando una clave primaria compuesta
-- es decir primary key(letra,codigo)
-- cada campo por si solo no es clave, ni tampoco identifica al registro
-- pero la suma de los dos forman la clave


-- 6- Crear la tabla Articulos dentro de la base de datos con el siguiente detalle:

-- Codigo		integer auto_increment y PK 
-- Nombre 		varchar(50)
-- Precio		double
-- Stock		integer

-- 7- Cargar 5 registros aleatorios en cada tabla.

-- 8- Mostrar las tablas que tiene la base de datos comercio.

-- 9- Describir (detalle de campos - METADATO) cada una de las tablas de la base de datos.

-- 10- Listar los registros de cada tabla.






















































































