-- COMANDO ALTER
use negocio;

show tables;

describe clientes;

-- agrego la columna sueldo
alter table clientes
add column sueldo int; 

describe clientes;

select * from clientes;

-- update masivo
update clientes
set	sueldo = 400;

select * from clientes;

-- update 
update clientes
-- set	sueldo = 500
set	sueldo = 600
-- where	idcliente = 1;
where	nombre = 'juan' and apellido = 'perez';

select * from clientes;

-- modifico la columna sueldo
alter table clientes
modify column sueldo smallint;

-- modifico la columna sueldo
alter table clientes
change column sueldo sueldoNeto int not null;

describe clientes;

-- borro la columna sueldo
alter table clientes
drop column sueldoNeto;

describe clientes;

-- renombro la tabla clientes por amigos
rename table clientes to amigos;

show tables;

rename table amigos to clientes;

show tables;

-- borro la tabla de clientes
drop table clientes;











