/*
	DDL Data Definition Language
    create table
    alter table
    drop table
    truncate table
    
    DML Data Manipalition Language
    select
    insert
    delete
    update
    
*/

drop database if exists comercio;
create database comercio;
use comercio;

create table if not exists clientes (
codigo integer auto_increment,
nombre varchar(20) not null,
apellido varchar(20) not null,
cuit char(13),
direccion varchar(50),
comentarios varchar(140),
primary key (codigo)
);

create table facturas(
letra char(1),
numero integer,
fecha date,
monto double,
primary key (letra,numero)
);

create table articulos(
codigo integer auto_increment,
nombre varchar(50),
precio double,
stock integer,
primary key (codigo)
);

insert into clientes (nombre,apellido,cuit,direccion) values ('juan','perez','xxxxx','peru 323');
insert into clientes (nombre,apellido,cuit,direccion) values ('diego','torres','xxxxx','chile 320');
insert into clientes (nombre,apellido,cuit,direccion) values ('laura','gomez','xxxxx','san juan 420');
insert into clientes (nombre,apellido,cuit,direccion) values ('mario','lopez','xxxxx','lavalle 770');
insert into clientes (nombre,apellido,cuit,direccion) values ('dario','sanchez','xxxxx','mexico 150');

insert into articulos values (1,'destornillador',25,50);
insert into articulos values (2,'pinza',35,22);
insert into articulos values (3,'martillo',15,28);
insert into articulos values (4,'maza',35,18);
insert into articulos values (5,'valde',55,13);

insert into facturas values ('a',0001,'2011/10/18',500);
insert into facturas values ('a',0002,'2011/10/18',2500);
insert into facturas values ('b',0003,'2011/10/18',320);
insert into facturas values ('b',0004,'2011/10/18',120);
insert into facturas values ('b',0005,'2011/10/18',560);
-- inserto un registro con la fecha actual
insert into facturas values ('c',0006,curdate(),300);

insert into clientes (nombre,apellido,cuit,direccion) values ('maria','fernandez','xxxxx','');
insert into clientes (nombre,apellido,cuit,direccion) values ('gustavo','ramirez','xxxxx',null);


insert into facturas values ('f',0006,curdate(),300);
insert into facturas values ('f',0007,curdate(),400);

insert into clientes (nombre,apellido,cuit,direccion) values ('jose','benuto','3647493','loria 940');

insert into facturas (letra,numero,fecha,monto) values ('a',1001,'2012/10/25',350);
insert into facturas (letra,numero,fecha,monto) values ('a',1002,curdate(),540);

insert into articulos (codigo,nombre,precio,stock) values (110,'destornillador',30,100);
insert into articulos (codigo,nombre,precio,stock) values (111,'martillo',40*1.21,50);

insert into clientes (nombre,apellido,direccion) values ('Andrea','Abate','Laprida 648');
insert into clientes (apellido,nombre) values ('Stuart','Jhon');
-- insert into clientes (nombre,direccion) values ('Francisco','Cerrito 256');
insert into clientes values(null,'Laura','Georgeff','56565','Berutti 2589','');
insert into clientes (codigo,nombre,apellido,cuit,direccion) values (null,'jose','sanchez','xxxxx','chile 150');
insert into clientes values (null,'marta','martinez','xxxxx','florida 150','');
insert into clientes (nombre,apellido,cuit,direccion) values ('carlos','flores','xxxxx','bolivar 150');
insert into clientes values (20,'Romeo','Lopez','34343434','Anchorena 950','');
insert into clientes (nombre,apellido,cuit,direccion) values ('Florencia','Salinas','82828282','W.Morris 3420');
insert into clientes (apellido,nombre,direccion) values ('Ana','Salone',null);

use comercio;
show tables;

-- Comando DML Insert

-- Insert normal con definición de campos	(ANSI)
insert into clientes (nombre,apellido,direccion) values
	('Leandro','Miranda','Lima 222');

-- Insert abreviado sin definición de campos (ANSI) 
insert into clientes values 
	(null,'Francisco','Cerrito','11111','Medrano 333','');

-- insert set (NO ANSI)
insert clientes set nombre='Raul',apellido='Ledesma';
insert clientes set nombre='Margarita', apellido='Vila'
	,direccion='Larrea 222';
    

-- insert masivo (ANSI)
insert into clientes (nombre,apellido) values
	('Jose','Cerezo'),
    ('Matias','Juarez'),
    ('Patricia','Pascua'),
    ('Magali','Jimenez');

-- comando DML delete (ANSI)
select * from clientes;
delete from clientes where codigo=3;
-- delete from clientes where nombre='laura';
select * from clientes where nombre='laura';

-- desactivamos la protección safe updates
set sql_safe_updates=0;			-- =1; para activar

-- borrado masivo
-- delete from clientes where nombre like 'c%';
-- delete from clientes;

insert into clientes (codigo,nombre,apellido) values
(200,'Homero','Simpsom');
delete from clientes where codigo=200;

select * from clientes;

insert into clientes (nombre,apellido) values ('Bart','Simpson');

-- delete from clientes;
insert into clientes (nombre,apellido) values ('Lisa','Simpson');

-- comando ddl truncate
-- truncate clientes;

-- comando DML update (ANSI)
update clientes set nombre='Gabriel', apellido='Racing' 
	where codigo=2;
update clientes set cuit='Campeon' where codigo=2;
select * from clientes;

-- updates masivos
update clientes set nombre='Maria' where nombre='Mario';
-- update clientes set nombre='Maria';

-- comando DDL Alter table (ANSI)

-- alter table add
alter table clientes add edad int;
alter table clientes add telefono varchar(20) after cuit;
alter table clientes add dni char(8) first;
describe clientes;

update clientes set edad=33 where codigo=1;
update clientes set edad=44 where codigo=2;

select * from clientes;

-- alter table modify
alter table clientes modify edad tinyint unsigned;
describe clientes;

alter table clientes modify edad tinyint unsigned after cuit;

-- alter table drop
alter table clientes drop edad;
alter table clientes drop telefono;
alter table clientes drop dni;

-- 1 - Ingrese a la base de datos comercio.

-- 2 - Ingrese 5 registros aleatorios en cada tabla.

-- 3 - Basándose en la tabla artículos obtener los siguientes listados.

-- a-	artículos con precio mayor a 100
select * from articulos where precio > 100;
-- b-	artículos con precio entre 20 y 40 (usar < y >)
select * from articulos where precio >=20 and precio <=40;
-- c-	artículos con precio entre 40 y 60 (usar BETWEEN)
select * from articulos where precio between 40 and 60;
-- d-	artículos con precio = 20 y stock mayor a 30
select * from articulos where precio = 20 and stock >30;
-- e-	artículos con precio (12,20,30) no usar IN
select * from articulos where precio = 12 or precio =20 or precio=40;
-- f-	artículos con precio (12,20,30) usar el IN
select * from articulos where precio in (12,20,30);
-- g-	artículos que su precio no sea (12,20,30)
select * from articulos where precio not in (12,20,30);
-- h-   artículos que su precio mas iva(21 %) sea mayor a 100
select * from articulos where precio*1.21>100;
-- i-   listar nombre y descripción de los artículos que no cuesten 
--      $100
select * from articulos where precio != 100;
-- j- 	artículos con nombre que contengan la cadena 'lampara' 
--      (usar like)
select * from articulos where nombre like '%lampara%';
-- k-   artículos que su precio sea menor que 200 y en su nombre no 
--      contenga la letra 'a'
select * from articulos where precio < 200 and nombre not like '%a%';
-- 	2- Listar los artículos ordenados por precio de mayor a menor, 
--     y si hubiera precio iguales deben quedar ordenados por nombre.
select * from articulos order by precio desc, nombre;
-- 	3- Listar todos los artículos incluyendo una columna denominada 
--     precio con IVA, la cual deberá tener el monto con el iva del 
--     producto.
select codigo,nombre,precio,round(precio*1.21,2) precio_con_iva, 
	stock from articulos;

-- 	4- Listar todos los artículos incluyendo una columna denominada 
--     'cantidad de cuotas' y otra 'valor de cuota', la cantidad es 
--     fija y es 3, el valor de cuota corresponde a 1/3 del monto 
--     con un 5% de interés.
select codigo,nombre,precio,3 cantidad_de_cuotas,
	round(precio/3*1.05,2) valor_cuota, stock
	from articulos;

-- Usando la base de datos comercio.

-- Basándose en la tabla clientes realizar los siguientes puntos.

-- 1- 	Insertar 5 clientes en la tabla clientes utilizando el insert into sin utilizar campos como parte de la sentencias, es decir de la forma simplificada.
-- 2-	Insertar 5 clientes en la tabla clientes utilizando los campos como parte de la sentencias, es decir de la forma extendida. Completar solo los campos nombre, apellido y CUIT.
-- 3-	Actualizar el nombre del cliente 1 a Jose.
-- 4-	Actualizar el nombre apellido y cuit del cliente 3 a Pablo Fuentes 20-21053119-0.
-- 5-	Actualizar todos los comentarios NULL  a ''.
-- 6-	Eliminar los clientes con apellido Perez.
-- 7-	Eliminar los clientes con CUIT Terminan en 0.

-- Basando se en la tabla artículos, realizar los siguientes puntos.
-- 	8- Aumentar un 20% los precios de los artículos con precio menor igual a 50.
-- 	9- Aumentar un 15% los precios de los artículos con precio mayor a 50.
-- 	10- Bajar un 5% los precios de los artículos con precio mayor a 200.
-- 	11- Eliminar los artículos con stock menor a 0.

-- 	12- Agregar a la tabla articulos, los campos stockMinimo y stockMaximo. (usar alter table add)
--  13- Completar en los registros los valores de los campos stockMinimo y stockMaximo (usar update)
--      teniendo en cuenta que el stock mínimo debe ser menor que el stock máximo.
--  14- Lista los articulos que se deben reponer y que cantidad se debe reponer de cada articulos.
--      Tener en cuenta que se debe reponer cuando el stock es menor al stockMinimo y la cantidad de articulos a 
--      reponer es stockMaximo - stock.
--  15- Calcular el valor de venta de toda la mercaderia que hay en stock.
--  16- Calcular el valor de venta + iva de toda la mercaderia que hay en stock.








